package services;

import java.util.ArrayList;
import java.util.List;
import dao.Userdao;
import entities.User;

import java.util.List;

import dao.Userdao;
import entities.User;

public class Userservice implements Service<User> {

	@Override
	public boolean create(User t) {
		try{// TODO Auto-generated method stub
		return Userdao.insertUser(t);
		}catch(Exception ex) {
			System.out.print(ex.getMessage());
			return false;
		}
	}

	@Override
	public boolean update(int id, User t) {
		try {
			return Userdao.updateUser(t);

		}catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
			return false;
		}
	}

	@Override
	public boolean delete(int id) {
		try {
			return Userdao.deleteUser(id);

		}catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
			return false;
		}
	}

	@Override
	public List<User> getAll() {
		// TODO Auto-generated method stub
			try {
				return Userdao.getAllUsers();

			}catch(Exception ex) {
				System.out.print(ex.getMessage());
				return new ArrayList<>();
			}
	}

	@Override
	public User findById(int id) {
		return null;
	}

}
