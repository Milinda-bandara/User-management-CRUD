package controller;

import java.io.IOException;
import java.util.List;

import entities.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import services.Userservice;


public class UserController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	String complete_url=request.getRequestURI();
		String domain= request.getContextPath();
		String action=complete_url.substring(domain.length());
	
		if(action.equals("/")) {
			getUser(request, response);
		}else if(action.equals("/users/new")){
			getCreatePage(request, response);
		}else if(action.equals("/users/delete")){
			getDeletePage(request, response);
		}else if(action.equals("/users/update")){
			getUpdatePage(request, response);
		}
		
    }
    
    private void getCreatePage(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/views/user-form.jsp").forward(request, response);
    }

    public void getUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<User> user_list = new Userservice().getAll();
		request.setAttribute("user_list", user_list);
		request.getRequestDispatcher("views/user-list.jsp").forward(request, response);
	}
    

	public void getUpdatePage(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/views/user-update.jsp").forward(request, response);
	}
	
	public void getDeletePage(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/views/user-delete.jsp").forward(request, response);
	}
	

    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	String action=request.getRequestURI().substring(request.getContextPath().length());
		if(action.equals("/users/new")) {
			createUser(request,response);
		}else if(action.equals("/users/update")) {
			updateUser(request,response);
		}else if(action.equals("/users/delete")) {
			deleteUser(request, response);
		}
    }

    
    public void createUser(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String mobile = request.getParameter("mobile");
        String dob = request.getParameter("dob");
        String city = request.getParameter("city");
        String gender = request.getParameter("gender");

        User user = new User();
        
        user.setName(name);
        user.setEmail(email);
        user.setMobile(mobile);
        user.setDob(dob);
        user.setCity(city);
        user.setGender(gender);

        boolean result = new Userservice().create(user);

        if (result) {
            response.sendRedirect(request.getContextPath() + "/");
        } else {
            response.sendRedirect(request.getContextPath() + "/users/new");
        }
    }
    
    public void updateUser(HttpServletRequest request, HttpServletResponse response) throws IOException{
		 String id =request.getParameter("id");
		 String name = request.getParameter("name");
	     String email = request.getParameter("email");
	     String mobile = request.getParameter("mobile");
	     String dob = request.getParameter("dob");
	     String city = request.getParameter("city");
	     String gender = request.getParameter("gender");

	    if(id !=null || id.isEmpty()) {
	    	
	    	int iduser =Integer.parseInt(id);
	    	User user=new User();
	    	
	    	  user.setId(iduser);
	    	  user.setName(name);
	          user.setEmail(email);
	          user.setMobile(mobile);
	          user.setDob(dob);
	          user.setCity(city);
	          user.setGender(gender);
	          
			boolean result= new Userservice().update(iduser, user);
			
			if (result) {
                response.sendRedirect(request.getContextPath() + "/");
            } else {
                response.sendRedirect(request.getContextPath() + "/users/update?id=" + iduser);
            }
        } else {
            		//invalid id
            response.sendRedirect(request.getContextPath() + "/");
        }
	}
    
    public void deleteUser(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	
        String id = request.getParameter("id");

        if (id != null && !id.isEmpty()) {
            int userId = Integer.parseInt(id);

            boolean result = new Userservice().delete(userId);

            if (result) {
                response.sendRedirect(request.getContextPath() + "/");
            } else {
                //  user not found or deletion failed
                response.sendRedirect(request.getContextPath() + "/users/delete?id=" + userId);
            }
        } else {
            //  invalid or missing user ID
            response.sendRedirect(request.getContextPath() + "/");
        }


 }
}
