package entities;

import java.io.Serializable;

public class User implements Serializable {
	
	private int id;
	private String name;
	private String email;
	private String mobile;
	private String dob;
	private String city;
	private String gender;
	
	//getters and setters
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	//constructor
	
	public User() {

		this.id = 0;
		this.name = "";
		this.email = "";
		this.mobile = "";
		this.dob = "";
		this.city = "";
		this.gender = "";
	}



}
