package dao;

import java.sql.Connection;
import java.sql.DriverManager;


public class Mysqlconnection implements Dbconnector {
	@Override
	public Connection connectDB() {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url="jdbc:mysql://127.0.0.1:3306/user-management";    //database
			String un="root";
			String pw="";
			Connection con=DriverManager.getConnection(url,un,pw);
			return con;
			
		}catch(Exception ex){		//if cant connect
			    ex.printStackTrace();
	            System.out.println("Could not connect to the database");
	            return null;
			}
	}
}
