package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import entities.User;

public class Userdao {
    public static   List<User> getAllUsers() throws SQLException {
    	
        Mysqlconnection connector = new Mysqlconnection();
        Connection con = connector.connectDB();
        
        String query = "select * from users";
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery(query);
        List<User> users = new ArrayList<>();
        
        while (rs.next()) {
            User user = new User();
            user.setId(rs.getInt("id"));
            user.setName(rs.getString("name"));
            user.setEmail(rs.getString("email"));
            user.setMobile(rs.getString("mobile"));
            user.setDob(rs.getString("dob"));
            user.setCity(rs.getString("city"));
            user.setGender(rs.getString("gender"));
            users.add(user);
        }
        stmt.close();
        con.close();
        return users;
    }

    public static boolean insertUser(User user) throws SQLException {
    	
        Mysqlconnection connector = new Mysqlconnection();
        Connection con = connector.connectDB();
        
        String query = "insert into users (name, email, mobile, dob, city, gender) values (?, ?, ?, ?, ?, ?)";
        
        PreparedStatement stmt = con.prepareStatement(query);
        stmt.setString(1, user.getName());
        stmt.setString(2, user.getEmail());
        stmt.setString(3, user.getMobile());
        stmt.setString(4, user.getDob());
        stmt.setString(5, user.getCity());
        stmt.setString(6, user.getGender());
        
        if(stmt.executeUpdate()>0) {
			return true;

		}else {
			return false;
		}
    }
    public static boolean updateUser(User user) throws SQLException{
    	
		Mysqlconnection connector= new Mysqlconnection();
		Connection con=connector.connectDB();

		String query = "update users set name=?, email=?, mobile=?,dob=?,city=?,gender=? where id=?";

		PreparedStatement stmt = con.prepareStatement(query);
		stmt.setString(1, user.getName());
        stmt.setString(2, user.getEmail());
        stmt.setString(3, user.getMobile());
        stmt.setString(4, user.getDob());
        stmt.setString(5, user.getCity());
        stmt.setString(6, user.getGender());
	    stmt.setInt(7, user.getId());
	    
	        int rowsAffected = stmt.executeUpdate();

	        stmt.close();
	        con.close();

	        return rowsAffected > 0;
	}
    
    public static boolean deleteUser(int id) throws SQLException{
    	
    	try {
		Mysqlconnection connector = new Mysqlconnection();
		Connection con= connector.connectDB();
		String query = "delete from users where id=?";
		PreparedStatement stmt = con.prepareStatement(query);
		stmt.setInt(1, id);
		int rowsAffected = stmt.executeUpdate();

	    stmt.close();
	    con.close();

	    return rowsAffected > 0;
		 } catch (SQLException e) {
		        e.printStackTrace(); 
		        return false;
		    }

	
    }
	
}
