package dao;

import java.sql.Connection;

public interface Dbconnector {
	
	public Connection connectDB();

}
